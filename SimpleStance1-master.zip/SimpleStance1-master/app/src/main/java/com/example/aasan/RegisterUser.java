package com.example.aasan;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Objects;

public class RegisterUser extends AppCompatActivity implements View.OnClickListener{
    private FirebaseAuth mAuth;
    private TextView banner, registerUser;
    private EditText text_name, text_age, text_email, text_password;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);

        mAuth = FirebaseAuth.getInstance();

        //this is the tag- Solution to all the posture problems
        banner = (TextView) findViewById(R.id.register_banner);
        banner.setOnClickListener(this);

        //BUtton to register the User information
        registerUser = (Button) findViewById(R.id.register_user);
        registerUser.setOnClickListener(this);

        text_name = (EditText) findViewById(R.id.register_name);
        text_age = (EditText) findViewById(R.id.register_age);
        text_email = (EditText) findViewById(R.id.forgot_password_email);
        text_password = (EditText) findViewById(R.id.register_password);

        progressBar = (ProgressBar) findViewById(R.id.register_progressbar);



    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.register_banner://if its banner, we need to redirect back to the home page.
                startActivity(new Intent(this,MainActivity.class));
                break;

            case R.id.register_user:
                registerUser();
                break;


        }
    }

    private void registerUser() {

        String  email  = text_email.getText().toString().trim();
        String  name  = text_name.getText().toString().trim();
        String  age  = text_age.getText().toString().trim();
        String  password  = text_password.getText().toString().trim();
//these are the validations so that the user does not submit an empty form.
        if(name.isEmpty()){
            text_name.setError("Full name is required");
            text_name.requestFocus();
            return;
        }


        if(email.isEmpty()){
            text_email.setError("Email is required");
            text_email.requestFocus();
            return;
        }

        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            text_email.setError("Please enter a valid email");
            text_email.requestFocus();
            return;
        }

        if(age.isEmpty()){
            text_age.setError("Age is required");
            text_age.requestFocus();
            return;
        }


        if(password.isEmpty()){
            text_password.setError("Password is required");
            text_password.requestFocus();
            return;
        }

        if(password.length()<6)
        {
            text_password.setError("Please enter a password of length greater than 6 characters");
            text_password.requestFocus();
            return;
        }

        //the bar becomes visible after the button becomes true.
        progressBar.setVisibility(View.VISIBLE);
        mAuth.createUserWithEmailAndPassword(email,password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>(){ //we are checking if th user registered.
            @Override
            public void onComplete (@NonNull Task<AuthResult> task)
            {
                if(task.isSuccessful()){
                    //once the user has been registered we will store the real time info in the Reacl time DB.
                    User user = new User (name, age, email);
                    //now we will send it to FB
                    FirebaseDatabase.getInstance().getReference("users")//name of collection
                            .child(Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid())
                            //we ad the ID above so we correspond the object to the registered user.
                            .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                //we then set this user object to the ID obtained.
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()){//if the user has been registered and added to DB.
                                //Toast is a small grey notif appearing at the bottom half.                           L_L- means it will stay for a quite good amount of time.
                                Toast.makeText(RegisterUser.this, "User has been successfully registered!", Toast.LENGTH_LONG).show();
                                progressBar.setVisibility(View.VISIBLE);
                                //to start the demo homepage later making a class to start homepage
//                                setContentView(R.layout.homepage);
//                                startActivity(new Intent(this, profile_user.class));

                            }
                            else{//if the user has not been registered successfully and connected the USer object.
                                Toast.makeText(RegisterUser.this, "Failed to register, try again!", Toast.LENGTH_LONG).show();
                                progressBar.setVisibility(View.GONE);
                            }
                        }
                    });

                }else
                {//if hte user has failed to register ain the first place.
                    Toast.makeText(RegisterUser.this, "Failed to register, try again!", Toast.LENGTH_LONG).show();
                    progressBar.setVisibility(View.GONE);
                }
            }
        });


    }

}