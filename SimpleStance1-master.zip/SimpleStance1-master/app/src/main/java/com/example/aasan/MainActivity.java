//DHURVA MALIK Aasan
//RITHIK KAPOOR Aasan
//SRI SUBHASH PATHURI Aasan

package com.example.aasan;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    //this is for the basic login screen screen
    private TextView register,forgot_password;
    private EditText email_input, password_inp;//this is for the login page/
    private Button login;
    private ProgressBar p_bar;
    private FirebaseAuth mauth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //we are finding the ID from the login page and creating their respective varaibles.
        register = (TextView) findViewById(R.id.login_register);
        register.setOnClickListener(this);
        login = (Button) findViewById(R.id.button_login);
        login.setOnClickListener(this);
        email_input = findViewById(R.id.login_email);
        password_inp = findViewById(R.id.login_password);
        mauth = FirebaseAuth.getInstance();
        forgot_password = (TextView) findViewById(R.id.login_forgotpassword);
        forgot_password.setOnClickListener(this);

    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {
        switch (v.getId())
        {//we are using a switch case to redirect to all onClick listeners to respond to multiple buttons.
            case R.id.login_register://we are redirecting to that page.we will be redirected to the Registration page.
                startActivity(new Intent(this, RegisterUser.class));
                break;
            case R.id.button_login://this wis fir
                userlogin();//this is the method for doing the process
                break;
            case R.id.login_forgotpassword:
                startActivity(new Intent(this, forgot_password.class));

        }
    }

    private void userlogin() {
        //initializing the variables
        String email = email_input.getText().toString().trim();
        String password = password_inp.getText().toString().trim();

        //we are doing validations here
        if(email.isEmpty()){
            email_input.setError("Email is required");
            email_input.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            email_input.setError("Please enter a valid email");
            email_input.requestFocus();
            return;
        }
        if(password.isEmpty()){
            password_inp.setError("Password is required");
            password_inp.requestFocus();
        }
        if(password.length()<6){
            password_inp.setError("Min password length is 6 characters");
            password_inp.requestFocus();
            return;
        }

        //we didnot add a progress bar.-v2-1:20min
        //
        //verification with Firebase/ we are also checking if the task has been completed
        mauth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){//if logged in, redirect him to the User profile page.


                    //We need to check if the email provided has been verified initially or not.
                    startActivity(new Intent(MainActivity.this, user_profile.class));
                }
                else{
                    Toast.makeText(MainActivity.this, "Failed to Login! P   lease check your credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });



    }

//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.homepage);
//
//
//    }
}