package com.example.aasan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class user_profile extends AppCompatActivity {
    private Button camera_input_button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);
        camera_input_button = (Button) findViewById(R.id.camera_button);
        camera_input_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                camera_input_activity();
            }
        });

    }
    public void camera_input_activity()
    {
        Intent intent = new Intent(this,activity_camera.class);
        startActivity(intent);
    }
}