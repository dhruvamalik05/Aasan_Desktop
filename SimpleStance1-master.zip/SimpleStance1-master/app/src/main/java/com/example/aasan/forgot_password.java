package com.example.aasan;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class forgot_password extends AppCompatActivity {
    private EditText email_input;
    private Button reset_button;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        email_input = (EditText) findViewById(R.id.forgot_password_email);
        reset_button= (Button) findViewById(R.id.reset_password_button);
        auth = FirebaseAuth.getInstance();
        reset_button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v)
            {
                reset_button();
            }
        });
    }
    public void reset_button(){
        String email = email_input.getText().toString().trim();
        if(email.isEmpty()){
            email_input.setError("Email is required");
            email_input.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            email_input.setError("Please enter a valid email");
            email_input.requestFocus();
            return;
        }

        auth.sendPasswordResetEmail(email).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    Toast.makeText(forgot_password.this, "Check your email to reset your password!", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(forgot_password.this, "Failed! Something wrong happened!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}