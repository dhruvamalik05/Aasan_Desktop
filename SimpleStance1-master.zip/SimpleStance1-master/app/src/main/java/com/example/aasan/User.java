package com.example.aasan;

import android.content.Intent;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class User {

    public String name, age, email;
    public User(){
    //through this empty constructor, we can create an empty class at any time.
    }

    public User(String name, String age,String email)
    {
        this.name = name;
        this.age = age;
        this.email = email;
    }

    //any other functions for the user can be made here



}
